%%  Declarations

clc;
clear;
close all;

delta = 0;%2*pi*2e6; %Detuning
t2=13e-9; %Relaxation Time T2
t1=0.5*t2; 
E0=1e6;   %Electric Field Strength
f=4.470631e14; %frequency
y0 = [0 ;-1]; %initial conditions origianlly [0,-1]
ft=linspace(0,30e-9,100000); 
%ft=linspace(-10e-10,10e-10,1000); 

efieldnormal = E0;

width = (100e-12)^2; %width in Seconds Squared
efieldgaussian = E0*exp((-(ft-10e-10).^2)./(2*width));

h = 6.63e-34;
hbar = h/(2*pi);

dipoletransition = 5.2*3.33564095e-30;

%E0*exp(1j*2*pi*f*ft).*exp((-((ft-1e-10).^2)./2e-21));
%% Rabi Frequency Calc
rabifreq=2*(dipoletransition*E0/hbar)/(2*pi); %in HZ;
Equivalentfreq = sqrt(rabifreq^2 + ((delta)/(2*pi))^2); %in Hz

%% E field Curves

figure(1)
subplot(2,1,1)
plot(ft,abs(efieldnormal*ones(length(ft),1)));
set(gca,"FontSize",20)
title('Constant Electric Field Amplitude ','FontSize',20,'FontWeight','bold');
xlabel('t in s');
ylabel('Electric Field Intensity in V/m','FontSize',20,'FontWeight','bold');

subplot(2,1,2)
plot(ft,abs(efieldgaussian));
set(gca,"FontSize",20)
title('Electric Field with Gaussuian Envelope ','FontSize',20,'FontWeight','bold');
txt=['t in s',"Pulse width in s is ", sprintf('%10e',sqrt(width))];
xlabel(txt,'FontSize',20,'FontWeight','bold');
ylabel('Electric Field Intensity in V/m','FontSize',20,'FontWeight','bold');



%% Single Pulse
tic
[tb,pw2]=ode45(@(tb,pw) pol_pulse(tb,pw,delta,t2,t1,E0,f,width),[0:1e-14:10e-9], y0);
toc

pw2center = (pw2(:,1)).*exp(-1i*2*pi*f*tb).*1 + (conj((pw2(:,1))).*exp(1i*2*pi*f*tb).*1);

figure(2)

yyaxis left
plot(tb,pw2center);
set(gca,"FontSize",20)
txt = [" E field (V/m) is ",sprintf('%10e',E0), "RabiFreq in Hz is ",sprintf('%10e',rabifreq),"Pulse width in s is ", sprintf('%10e',sqrt(width))];
title(txt,'FontSize',20,'FontWeight','bold');
ylabel('Dipole Magnitude in C.m','FontSize',20,'FontWeight','bold');
% hold on
yyaxis right
plot(ft,efieldgaussian);
set(gca,"FontSize",20)
ylabel('Electric Field Intensity in V/m','FontSize',20,'FontWeight','bold');
% hold off
xlabel('t in s','FontSize',20,'FontWeight','bold');
%xlim([0 0.2e-9]);
figure(3)

plot(tb,pw2(:,2));
set(gca,"FontSize",20)
%plot(t,pw(:,2));


%% FFT

t = tb;
v = pw2(:,1);

f_fund=4.70631*1e14;
Fs=4e15;
targetSampleRate = Fs;
[vr,ty] = resample(v,tb,targetSampleRate,'linear');
vrcenter = ((vr).*exp(-1i*2*pi*f_fund*ty).*1) + (conj(vr).*exp(1i*2*pi*f_fund*ty).*1);

Lvr=length(vrcenter);
Fn = Fs/2;                                                  % Nyquist Frequency
FTvr = abs(fft(vrcenter))/Lvr;                                           % Fourier Transform

Fv = linspace(0, 1, fix(Lvr/2)+1)*Fn;                         % Frequency Vector
Iv = 1:length(Fv);                                          % Index Vector

figure(4)

plot(Fv, (FTvr(Iv))*2);
set(gca,"FontSize",20)
txt = [" E field (V/m) is ",sprintf('%10e',E0), "RabiFreq in Hz is ", sprintf('%10e',rabifreq), sprintf('%10e',sqrt(width))];
title(txt,'FontSize',20,'FontWeight','bold');
grid
xlabel("f (Hz)",'FontSize',20,'FontWeight','bold');
ylabel("Amplitude in C.m ",'FontSize',20,'FontWeight','bold');
%xlim([4.69e14 4.71e14]);
);


