%%  Declarations

clc;
clear;
close all;

delta = 0;%2*pi*2e6; %Detuning
t2=13e-9; %Relaxation Time T2
t1=0.5*t2; 
E0=1e4;   %Electric Field Strength
f=4.470631e14; %frequency
y0 = [0 ;-1]; %initial conditions origianlly [0,-1]
ft=linspace(0,2e-9,100000); 
%ft=linspace(-10e-10,10e-10,1000); 

efieldnormal = E0;

width = (100e-12)^2; %width in Seconds Squared
chirp = 1; %hz
efieldgaussian_chirp = E0*exp((-(ft-10e-10).^2)./(2*width)).*exp(-1i*2*pi*ft.^2.*f.*(1).*2*pi*(chirp/2));

h = 6.63e-34;
hbar = h/(2*pi);

dipoletransition = 5.2*3.33564095e-30;

%E0*exp(1j*2*pi*f*ft).*exp((-((ft-1e-10).^2)./2e-21));
%% Rabi Frequency Calc
rabifreq=2*(dipoletransition*E0/hbar)/(2*pi); %in HZ;
Equivalentfreq = sqrt(rabifreq^2 + ((delta)/(2*pi))^2); %in Hz

%% E field Curves

figure(1)
subplot(2,1,1)
plot(ft,abs(efieldnormal*ones(length(ft),1)));
set(gca,"FontSize",20)
title('Constant Electric Field Amplitude ','FontSize',20,'FontWeight','bold');
xlabel('t in s');
ylabel('Electric Field Intensity in V/m','FontSize',20,'FontWeight','bold');

subplot(2,1,2)
plot(ft,(efieldgaussian_chirp + conj(efieldgaussian_chirp))/2);
set(gca,"FontSize",20)
title('Electric Field with Gaussuian Envelope ','FontSize',20,'FontWeight','bold');
txt=['t in s',"Pulse width in s is ", sprintf('%10e',sqrt(width))," Chirp Factor is", sprintf('%10e',chirp)];
xlabel(txt,'FontSize',20,'FontWeight','bold');
ylabel('Electric Field Intensity in V/m','FontSize',20,'FontWeight','bold');

%% Dipole plot for both efield amplitude

% opts1 = odeset('RelTol',1e-6,'AbsTol',1e-42); %ODE Tolerence
% 
% tic
% [ta,pw1]=ode45(@(ta,pw) pol(ta,pw,delta,t2,t1,E0,f),[0 1e-7], y0, opts1);
% toc
% 
% figure(2)
% subplot(2,1,1)
% yyaxis left
% 
% plot(ta,abs(pw1(:,1)));
% title('Dipole Magnitude');
% ylabel('Dipole Magnitude');
% xlabel('t');
% 
% yyaxis right
% plot(ft,abs(efieldnormal));
% ylabel('Electric Field Intensity');

chirp = logspace(1,5,1000);
rmsvalue = zeros(1000,1);

%% Single Pulse
tic
parfor i=1:1000


[tb,pw2]=ode45(@(tb,pw) pol_chirp_pulse(tb,pw,delta,t2,t1,E0,f,width,chirp(i)),[0:1e-10:2e-9], y0);


pw2center = (pw2(:,1)).*exp(-1i*2*pi*f*tb).*1 + (conj((pw2(:,1))).*exp(1i*2*pi*f*tb).*1);

X = find(tb>1.6e-9); %%Times Greater than 1.4ns to 2ns
rmsvalue(i)=rms(pw2center(X)); %%RMS value at those instances

% fh = figure();
% fh.WindowState = 'maximized';
% 
% % yyaxis left
% plot(tb,pw2center);
% %set(gca,"FontSize",20)
% txt = [" E field (V/m) is ",sprintf('%10e',E0), "RabiFreq in Hz is ",sprintf('%10e',rabifreq),"Pulse width in s is ", sprintf('%10e',sqrt(width)), "Chirp factor is", sprintf('%10e',chirp(i))];
% title(txt)%,'FontSize',20,'FontWeight','bold');
% ylabel('Dipole Magnitude in C.m','FontSize',20,'FontWeight','bold');
% drawnow
% hold on
% yyaxis right
%plot(ft,(efieldgaussian_chirp+conj(efieldgaussian_chirp))/2,'ro');
% set(gca,"FontSize",20)
% ylabel('Electric Field Intensity in V/m','FontSize',20,'FontWeight','bold');
% % hold off
% xlabel('t in s','FontSize',20,'FontWeight','bold');

end
toc


%xlim([0 0.2e-9]);
% figure(3)
% 
% plot(tb,pw2(:,2));
% set(gca,"FontSize",20)
% %plot(t,pw(:,2));


%% FFT

% t = tb;
% v = pw2(:,1);
% 
% f_fund=4.70631*1e14;
% Fs=4e15;
% targetSampleRate = Fs;
% [vr,ty] = resample(v,tb,targetSampleRate,'linear');
% vrcenter = ((vr).*exp(-1i*2*pi*f_fund*ty).*1) + (conj(vr).*exp(1i*2*pi*f_fund*ty).*1);
% 
% Lvr=length(vrcenter);
% Fn = Fs/2;                                                  % Nyquist Frequency
% FTvr = abs(fft(vrcenter))/Lvr;                                           % Fourier Transform
% 
% Fv = linspace(0, 1, fix(Lvr/2)+1)*Fn;                         % Frequency Vector
% Iv = 1:length(Fv);                                          % Index Vector
% 
% figure(4)
% 
% plot(Fv, (FTvr(Iv))*2);
% set(gca,"FontSize",20)
% txt = [" E field (V/m) is ",sprintf('%10e',E0), "RabiFreq in Hz is ", sprintf('%10e',rabifreq), sprintf('%10e',sqrt(width))];
% title(txt,'FontSize',20,'FontWeight','bold');
% grid
% xlabel("f (Hz)",'FontSize',20,'FontWeight','bold');
% ylabel("Amplitude in C.m ",'FontSize',20,'FontWeight','bold');
%xlim([4.69e14 4.71e14]);

% %% Fourier transform of Dipole Amplitide
% 
% Fs = 1e14; %sampling Frequency
% L1=length(ta); 
% L2=length(tb); %FFT Length
% 
% T=1/Fs; %Time Period
% 
% Y1=fft(pw1(:,1));
% Y2=fft(pw2(:,1));
% 
% 
% % ydft = fftshift(Y1);
% % df = Fs/length(ta);
% % freqvec = -Fs/2+df:df:Fs/2;
% % f((N+1)/2+1:end) = f((N+1)/2+1:end)-fs
% 
% % figure(4)
% % plot(freqvec,abs(ydft));
% 
% 
% P21=abs(Y1/L1); %Unnnormalized
% %P11=P21(1:(((L1+1)/2)));
% P11 = P21(1:(L1-1)/2+1);
% P11(2:end-1)=2*P11(2:end-1);
% 
% P22=abs(Y2); %Unnnormalized
% P12=P22(1:((L2/2)+1));
% P12(2:end-1)=2*P12(2:end-1);
% 
% 
% %fs1=Fs*(0:(L1/2))/L1;
% fs1 = Fs*(0:(L1/2))/L1;
% figure(3)
% subplot(2,2,1)
% plot(fs1,P11);
% title('FFT of Dipole Moment')
% xlabel('Frequency');
% ylabel("Amplitude");
% 
% [pks1,locs1] = findpeaks(P11, fs1, 'SortStr','descend','NPeaks', 2); %Find Peaks in frequency 
% hold on
% plot(locs1,pks1);
% disp('Peak 1 is at:');
% disp(locs1(1));
% disp('Distance Between Sidebands:');
% disp(locs1(2)-locs1(1));
% hold off
% 
% subplot(2,2,2)
% plot(fs1,log10(P11)); %log scale
% title('Log plot of FFT of Dipole Moment')
% xlabel('Frequency');
% ylabel("log10(Amplitude)");
% 
% fs2=Fs*(0:(L2/2))/L2;
% subplot(2,2,3)
% plot(fs2,P12);
% title('FFT of Dipole Moment with Gaussian Envelope')
% xlabel('Frequency');
% ylabel("Amplitude");
% 
% [pks2,locs2] = findpeaks(P12, fs2, 'SortStr','descend','NPeaks', 3); %Find Peaks in frequency
% hold on
% plot(locs2,pks2);
% disp('Peak 1 w/Guassian Envelope is at:');
% %disp(locs2(1));
% disp('Distance Between Sidebands w/ Guassian Envelope:');
% %disp(locs2(2)-locs2(1));
% hold off
% 
% subplot(2,2,4)
% plot(fs2,log10(P12));
% title('Log Plot of FFT of Dipole Moment with Gaussian Envelope ');
% xlabel('Frequency');
% ylabel("Log10(Amplitude)");%log scale



% %% Time Varing Detuning
% 
% 
% 
% tic
% [tc,pw3]=ode45(@(tc,pw) timevaryinggaussian(tc,pw,delta,t2,t1,E0,f),[0 5e-9], y0, opts);
% toc
% 
% figure(4)
% 
% yyaxis left
% plot(tc,abs(pw3(:,1)).^2);
% title('Dipole Magnitude with Gaussian Envelope');
% ylabel('Dipole Magnitude');
% 
% % hold on
% 
% yyaxis right
% plot(ft,abs(efieldgaussian));
% ylabel('Electric Field Intensity');
% 
% % hold off
% 
% xlabel('t');
% 
% % Fourier Transform Time Varying Detuning
% 
% 
% L3=length(tc);
% 
% Y3=fft(pw3(:,1));
% 
% P23=abs(Y3); %Unnormalized;
% P13=P23(1:((L3/2)+1));
% P13(2:end-1)=2*P13(2:end-1);
% 
% fs3=Fs*(0:(L3/2))/L3;
% figure(5)
% subplot(2,1,1)
% plot(fs3,P13);
% title('FFT of Dipole Moment')
% xlabel('Frequency');
% ylabel("Amplitude");
% 
% [pks3,locs3] = findpeaks(P13, fs3, 'SortStr','descend','NPeaks', 2); %Find Peaks in frequency 
% hold on
% plot(locs3,pks3);
% disp('Peak 1 is at:');
% disp(locs3(1));
% disp('Distance Between Sidebands:');
% 
% %disp(locs3(2)-locs3(1));
% 
% hold off
% 
% subplot(2,1,2)
% plot(fs3,log10(P13)); %log scale
% title('Log plot of FFT of Dipole Moment')
% xlabel('Frequency');
% ylabel("log10(Amplitude)");

figure;
semilogx(chirp,rmsvalue);
xlabel("Chirp Factor \alpha in Hz");
ylabel("RMS intensity between 1.4ns and 2ns (After Pulse) in C.m");
set(gca,"FontSize",20)
txt=[" E field (V/m) is ",sprintf('%10e',E0), "RabiFreq in Hz is ",sprintf('%10e',rabifreq),"Pulse width in s is ", sprintf('%10e',sqrt(width))];
title(txt);

