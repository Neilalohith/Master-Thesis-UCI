function dpdw = pol_chirp_pulse(t,pw,delta,t2,t1,E0,f,width,chirp)

h = 6.63e-34;
hbar = h/(2*pi);
ft=0:1e-15:2e-9;
efield = E0.*exp((-((ft-10e-10).^2)./(2*width))).*exp(-1i*2*pi*ft.^2.*f.*(1)*2*pi*(chirp/2));
%delta = 
DeltaVary = delta;% + erf(f/4.47e-11)*1e6;
%DeltaVary= interp1(ft,DeltaVary,t,'spline');
kappasq=(2*5.2*3.33564095e-30/hbar)^2;
dpdw = zeros(2,1);

efield = interp1(ft,efield,t,'spline');

dpdw(1)=(((1i*DeltaVary)-(1/t2))*pw(1)) - ((h/(8*pi))*1i.*efield*pw(2)*kappasq);
dpdw(2)= (-pw(2)/t1) - ((8*pi/h)*imag(conj(pw(1)).*efield));

end 